
document.addEventListener("DOMContentLoaded", function() {
    console.log("JavaScript is working!");

    // Form validation
    const form = document.querySelector('form');
    const skillsInput = document.getElementById('skills');
    const submitButton = document.querySelector('button');

    form.addEventListener('submit', function(event) {
        if (skillsInput.value.trim() === '') {
            alert('Please enter your skills before submitting.');
            event.preventDefault(); // Prevent form submission
        }
    });

});

