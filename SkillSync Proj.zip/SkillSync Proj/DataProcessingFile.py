import pandas as pd
from sklearn.model_selection import train_test_split

# Sample data: Replace this with actual data sources
data = pd.read_csv('job_trends.csv')

# Data preprocessing
data.dropna(inplace=True)

# Feature selection
features = data[['skill_1', 'skill_2', 'skill_3']]
target = data['in_demand_career']

X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
